# Sunward Roads

Игра, созданная Claude Opus 5.5 на уровне мышления **ultracode** по одному промпту: открытый мир в духе Forza Horizon на движке Godot 4.7 с 3D-моделями из Blender.

## Как запустить

| Система | Что нажать |
|---|---|
| **Windows** | двойной клик по `PLAY-Windows.bat` |
| **macOS** | двойной клик по `PLAY-Mac.command` |

Первый запуск дольше остальных: скачивается движок Godot и подготавливаются файлы игры (2–10 минут). Дальше игра стартует сразу.
Подробная инструкция для новичков: [главный README](../README.md).

## Что здесь лежит

| Файл / папка | Что это |
|---|---|
| `OPUS_5.5_FINAL_REPORT.md` | итоговый отчёт агента: что сделано, что работает, время, токены, стоимость |
| `DEVELOPMENT.md` | как устроена игра, управление, карта, результаты тестов |
| `FEATURE_MATRIX.md` | честная таблица: что работает, что частично, чего нет |
| `RESEARCH_NOTES.md` | исследование Forza Horizon 5, которое агент сделал перед работой |
| `PROGRESS.md` | журнал работы агента |
| `Prompt_6_ultracode.md` | промпт, по которому агент работал |
| `blender_source/` | исходный `.blend`-файл со всеми 3D-моделями |
| остальное | проект Godot: сцены, скрипты, ресурсы, 3D-модели |

## Touch controls

On phones and tablets the game switches to a touch layout automatically (on desktop: console `touch on`, the
`--touch` launch flag, or Pause > Settings > Touch controls).

- Bottom-left: steer left / right (slide a finger between them), bottom-right: brake and throttle pedals,
  handbrake above them, blue rewind button on the left (hold).
- Top-left: pause, map, headlights, horn, reset to road (hold). Top-right: camera, credits, minimap.
- Top-centre: speed bar with gear badge and digital speed. Shift buttons appear for manual gearboxes.
- Multi-touch, haptics, safe-area aware. Size / opacity / vibration are in Pause > Settings.
- Code: `scripts/ui/touch_controls.gd` (input), `touch_icons.gd` (glyphs), `hud_touch_top.gd` (speed bar),
  `touch_mode.gd` (mode switch). Buttons emit normal input actions, so keyboard and touch work together.
