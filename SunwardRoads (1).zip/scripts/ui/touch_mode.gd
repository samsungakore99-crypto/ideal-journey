extends RefCounted
## Touch UI mode switch. Settings "touch_controls": 0 = auto (phones / tablets, or the --touch launch flag),
## 1 = always on (handy for testing with a mouse), 2 = off. Everything touch related (on-screen controls,
## the compact top HUD, the relocated minimap / toasts, the world-map buttons) asks enabled().

const AUTO := 0
const ON := 1
const OFF := 2


static func enabled() -> bool:
	var mode := int(Settings.get_value("touch_controls", AUTO))
	if mode == ON:
		return true
	if mode == OFF:
		return false
	return auto_detect()


static func auto_detect() -> bool:
	if OS.get_cmdline_args().has("--touch") or OS.get_cmdline_user_args().has("--touch"):
		return true
	return OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")


## Safe-area insets (left, top, right, bottom) in canvas units, so controls clear notches and rounded corners.
static func safe_insets(canvas_size: Vector2) -> Vector4:
	if not OS.has_feature("mobile"):
		return Vector4.ZERO
	var win := Vector2(DisplayServer.window_get_size())
	if win.x < 1.0 or win.y < 1.0:
		return Vector4.ZERO
	var safe := Rect2(DisplayServer.get_display_safe_area())
	if safe.size.x <= 0.0 or safe.size.y <= 0.0:
		return Vector4.ZERO
	var k := Vector2(canvas_size.x / win.x, canvas_size.y / win.y)
	var l := maxf(safe.position.x, 0.0) * k.x
	var t := maxf(safe.position.y, 0.0) * k.y
	var r := maxf(win.x - safe.end.x, 0.0) * k.x
	var b := maxf(win.y - safe.end.y, 0.0) * k.y
	# Ignore absurd values (a desktop-sized "screen" larger than the window).
	return Vector4(minf(l, 160.0), minf(t, 120.0), minf(r, 160.0), minf(b, 120.0))
