extends RefCounted
## Procedural pictograms for the on-screen touch controls. Every glyph is drawn around centre `c` with
## unit `s` (about half the button radius), in colour `col`. `on` lights toggle glyphs (headlights).

const Style := preload("res://scripts/ui/ui_style.gd")


static func draw(ci: CanvasItem, icon: StringName, c: Vector2, s: float, col: Color, on := false) -> void:
	match icon:
		&"left":
			_arrow(ci, c, s, col, -1.0)
		&"right":
			_arrow(ci, c, s, col, 1.0)
		&"gas":
			_pedal(ci, c, s, col, false)
		&"brake":
			_pedal(ci, c, s, col, true)
		&"handbrake":
			_handbrake(ci, c, s, col)
		&"rewind":
			_rewind(ci, c, s, col)
		&"camera":
			_camera(ci, c, s, col)
		&"pause":
			_pause(ci, c, s, col)
		&"map":
			_pin(ci, c, s, col)
		&"lights":
			_lights(ci, c, s, col, on)
		&"horn":
			_horn(ci, c, s, col)
		&"reset":
			_reset(ci, c, s, col)
		&"shift_up":
			_chevron(ci, c, s, col, -1.0)
		&"shift_down":
			_chevron(ci, c, s, col, 1.0)
		&"close":
			_close(ci, c, s, col)
		&"plus":
			_plus(ci, c, s, col, true)
		&"minus":
			_plus(ci, c, s, col, false)


static func _closed(ci: CanvasItem, pts: PackedVector2Array, col: Color, w: float) -> void:
	ci.draw_colored_polygon(pts, col)
	var loop := pts.duplicate()
	loop.append(pts[0])
	ci.draw_polyline(loop, col, w, true)


static func _arrow(ci: CanvasItem, c: Vector2, s: float, col: Color, d: float) -> void:
	var pts := PackedVector2Array([
		c + Vector2(-0.55 * d, -0.85) * s, c + Vector2(0.9 * d, 0.0) * s, c + Vector2(-0.55 * d, 0.85) * s])
	_closed(ci, pts, col, s * 0.22)


static func _pedal(ci: CanvasItem, c: Vector2, s: float, col: Color, wide: bool) -> void:
	var size := Vector2(1.9, 1.15) * s if wide else Vector2(1.1, 2.0) * s
	var rect := Rect2(c - size * 0.5 + Vector2(0.15, 0.2) * s, size)
	Style.draw_round_rect(ci, rect, Color(col, col.a * 0.32), int(s * 0.3), maxi(int(s * 0.1), 2), col)
	var rib := Color(col, col.a * 0.7)
	var inset := s * 0.22
	if wide:
		var n := 6
		for i in n:
			var x := rect.position.x + inset + (rect.size.x - inset * 2.0) * (i + 0.5) / n
			ci.draw_line(Vector2(x, rect.position.y + inset), Vector2(x, rect.end.y - inset), rib, s * 0.1, true)
	else:
		var n := 6
		for i in n:
			var y := rect.position.y + inset + (rect.size.y - inset * 2.0) * (i + 0.5) / n
			ci.draw_line(Vector2(rect.position.x + inset, y), Vector2(rect.end.x - inset, y), rib, s * 0.1, true)
	# "+" (throttle) / "-" (brake) tag in the upper-left of the button.
	_plus(ci, c + Vector2(-1.2, -1.2) * s, s * 0.34, col, not wide)


static func _plus(ci: CanvasItem, c: Vector2, s: float, col: Color, plus: bool) -> void:
	ci.draw_line(c + Vector2(-s, 0), c + Vector2(s, 0), col, s * 0.32, true)
	if plus:
		ci.draw_line(c + Vector2(0, -s), c + Vector2(0, s), col, s * 0.32, true)


static func _handbrake(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var w := s * 0.2
	ci.draw_arc(c, s * 0.95, 0.0, TAU, 40, col, w, true)
	ci.draw_line(c + Vector2(0, -0.5) * s, c + Vector2(0, 0.12) * s, col, w * 1.1, true)
	ci.draw_circle(c + Vector2(0, 0.5) * s, w * 0.75, col, true, -1.0, true)
	ci.draw_arc(c, s * 1.38, PI - 0.6, PI + 0.6, 12, col, w, true)
	ci.draw_arc(c, s * 1.38, -0.6, 0.6, 12, col, w, true)


static func _rewind(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	_arrow(ci, c + Vector2(-0.55, 0.0) * s, s * 0.8, col, -1.0)
	_arrow(ci, c + Vector2(0.65, 0.0) * s, s * 0.8, col, -1.0)


static func _camera(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var body := Rect2(c + Vector2(-1.0, -0.45) * s, Vector2(1.5, 1.2) * s)
	Style.draw_round_rect(ci, body, col, int(s * 0.25))
	var lens := PackedVector2Array([c + Vector2(0.62, -0.05) * s, c + Vector2(1.25, -0.5) * s, c + Vector2(1.25, 0.8) * s, c + Vector2(0.62, 0.35) * s])
	ci.draw_colored_polygon(lens, col)
	ci.draw_circle(c + Vector2(-0.6, -0.72) * s, 0.36 * s, col, true, -1.0, true)
	ci.draw_circle(c + Vector2(0.05, -0.8) * s, 0.4 * s, col, true, -1.0, true)


static func _pause(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	for sx: float in [-1.0, 1.0]:
		Style.draw_round_rect(ci, Rect2(c + Vector2(0.28 * sx - 0.2, -0.8) * s, Vector2(0.4, 1.6) * s), col, int(s * 0.12))


static func _pin(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var head := c + Vector2(0, -0.3) * s
	ci.draw_circle(head, 0.72 * s, col, true, -1.0, true)
	ci.draw_colored_polygon(PackedVector2Array([head + Vector2(-0.62, 0.3) * s, head + Vector2(0.62, 0.3) * s, c + Vector2(0, 1.15) * s]), col)
	ci.draw_circle(head, 0.28 * s, Color(0.05, 0.06, 0.09, col.a), true, -1.0, true)


static func _lights(ci: CanvasItem, c: Vector2, s: float, col: Color, on: bool) -> void:
	var centre := c + Vector2(-0.35, 0.0) * s
	var pts := PackedVector2Array()
	for i in 13:
		var a := -PI * 0.5 + PI * i / 12.0
		pts.append(centre + Vector2(cos(a), sin(a)) * s * 0.85)
	var lc := Color(0.38, 0.78, 1.0, col.a) if on else col
	if on:
		ci.draw_colored_polygon(pts, lc)
	else:
		ci.draw_polyline(pts, lc, s * 0.2, true)
	ci.draw_line(centre + Vector2(0, -0.85) * s, centre + Vector2(0, 0.85) * s, lc, s * 0.2, true)
	for y: float in [-0.6, 0.0, 0.6]:
		ci.draw_line(c + Vector2(0.75, y) * s, c + Vector2(1.3, y * 1.25) * s, lc, s * 0.18, true)


static func _horn(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var cone := PackedVector2Array([
		c + Vector2(-1.0, -0.38) * s, c + Vector2(-0.35, -0.38) * s, c + Vector2(0.4, -0.9) * s,
		c + Vector2(0.4, 0.9) * s, c + Vector2(-0.35, 0.38) * s, c + Vector2(-1.0, 0.38) * s])
	_closed(ci, cone, col, s * 0.12)
	var o := c + Vector2(0.4, 0.0) * s
	ci.draw_arc(o, s * 0.7, -0.7, 0.7, 10, col, s * 0.16, true)
	ci.draw_arc(o, s * 1.05, -0.7, 0.7, 12, col, s * 0.16, true)


static func _reset(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var a0 := 0.3 * PI
	var a1 := 1.85 * PI
	var r := s * 0.82
	ci.draw_arc(c, r, a0, a1, 32, col, s * 0.22, true)
	var p := c + Vector2(cos(a1), sin(a1)) * r
	var n := Vector2(cos(a1), sin(a1))
	var t := Vector2(-sin(a1), cos(a1))
	ci.draw_colored_polygon(PackedVector2Array([p + n * 0.5 * s, p - n * 0.5 * s, p + t * 0.7 * s]), col)


## d = -1: chevron pointing up, d = 1: pointing down; a fainter second one trails behind it.
static func _chevron(ci: CanvasItem, c: Vector2, s: float, col: Color, d: float) -> void:
	var pts := PackedVector2Array([c + Vector2(-0.9, -0.35 * d) * s, c + Vector2(0.0, 0.45 * d) * s, c + Vector2(0.9, -0.35 * d) * s])
	ci.draw_polyline(pts, col, s * 0.3, true)
	var off := Vector2(0, -0.7 * d) * s
	ci.draw_polyline(PackedVector2Array([pts[0] + off, pts[1] + off, pts[2] + off]), Color(col, col.a * 0.55), s * 0.3, true)


static func _close(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	ci.draw_line(c + Vector2(-0.7, -0.7) * s, c + Vector2(0.7, 0.7) * s, col, s * 0.3, true)
	ci.draw_line(c + Vector2(0.7, -0.7) * s, c + Vector2(-0.7, 0.7) * s, col, s * 0.3, true)
