extends Control
## On-screen touch controls (layout copied from a mobile racing HUD): steer left / right bottom-left, brake and
## throttle pedals bottom-right, handbrake and rewind above them, pause / map / headlights / horn / reset on the
## top-left, camera top-right, shift buttons for manual gearboxes.
##
## True multi-touch: every finger is tracked by its own index, so steering, throttle and handbrake work at the
## same time. A finger can slide between the two steering buttons without lifting. Buttons never talk to the
## car directly: they emit InputEventAction events, so CarInput, the pause menu and the camera rig react exactly
## as they do to the keyboard. A real mouse acts as one finger when the touch UI is on (desktop testing).
##
## Shown when TouchMode.enabled() (phones by default; Settings "touch_controls"), hidden with the HUD, in menus
## and in photo mode. Size and opacity come from Settings "touch_scale" / "touch_opacity".

const Style := preload("res://scripts/ui/ui_style.gd")
const Icons := preload("res://scripts/ui/touch_icons.gd")
const TouchMode := preload("res://scripts/ui/touch_mode.gd")

const KIND_HOLD := 0   ## action is down while a finger is on the button
const KIND_TAP := 1    ## action pulses once (after hold_time, when set)
const KIND_CALL := 2   ## calls a Callable on touch-down

const TL := 0
const TR := 1
const BL := 2
const BR := 3

const TAP_TIME := 0.07
const MOUSE_ID := 1000


class Btn extends RefCounted:
	var id: StringName = &""
	var icon: StringName = &""
	var action: StringName = &""
	var kind: int = 0
	var group: int = 0
	var corner: int = 0
	var offset := Vector2.ZERO
	var radius: float = 60.0
	var grow: float = 1.18
	var slip: float = 2.4
	var icon_scale: float = 0.46
	var tint := Color(1, 1, 1)
	var glow: bool = false
	var hold_time: float = 0.0
	var manual_only: bool = false
	var callback := Callable()
	# runtime state
	var center := Vector2.ZERO
	var r: float = 60.0
	var visible: bool = true
	var finger: int = -1
	var pressed: bool = false
	var sent: bool = false
	var sent_t: float = 0.0
	var fired: bool = false
	var held_t: float = 0.0
	var anim: float = 0.0


var _btns: Array[Btn] = []
var _fingers: Dictionary = {}
var _lights_on: bool = false
var _opacity: float = 0.85


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_buttons()
	resized.connect(_layout)
	visibility_changed.connect(_on_visibility)
	Settings.changed.connect(_on_setting)
	Game.ui_overlay_changed.connect(func(_open: bool) -> void: _release_all())
	Game.photo_mode_changed.connect(func(_on: bool) -> void: _release_all())
	_apply_mode()
	_layout()


func _exit_tree() -> void:
	_release_all()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_release_all()


func _add(id: StringName, icon: StringName, kind: int, action: StringName, corner: int, off: Vector2, radius: float, opts := {}) -> Btn:
	var b := Btn.new()
	b.id = id
	b.icon = icon
	b.kind = kind
	b.action = action
	b.corner = corner
	b.offset = off
	b.radius = radius
	b.r = radius
	for k: String in opts:
		b.set(k, opts[k])
	_btns.append(b)
	return b


## Offsets are inward distances from the named screen corner, in 1080p canvas pixels (the screenshot layout).
func _build_buttons() -> void:
	_add(&"steer_left", &"left", KIND_HOLD, &"steer_left", BL, Vector2(190, 182), 88.0, {"group": 1, "grow": 1.35, "slip": 3.2})
	_add(&"steer_right", &"right", KIND_HOLD, &"steer_right", BL, Vector2(430, 182), 88.0, {"group": 1, "grow": 1.35, "slip": 3.2})
	_add(&"brake", &"brake", KIND_HOLD, &"brake", BR, Vector2(383, 182), 88.0, {"icon_scale": 0.52, "slip": 2.8})
	_add(&"gas", &"gas", KIND_HOLD, &"accelerate", BR, Vector2(157, 237), 95.0, {"icon_scale": 0.52, "slip": 2.8})
	_add(&"handbrake", &"handbrake", KIND_HOLD, &"handbrake", BR, Vector2(383, 460), 76.0, {"icon_scale": 0.42})
	_add(&"rewind", &"rewind", KIND_HOLD, &"rewind", BL, Vector2(182, 478), 66.0, {"glow": true, "tint": Style.SKY, "icon_scale": 0.42})
	_add(&"pause", &"pause", KIND_TAP, &"pause", TL, Vector2(117, 110), 60.0, {"icon_scale": 0.46})
	_add(&"map", &"map", KIND_CALL, &"", TL, Vector2(96, 250), 40.0, {"icon_scale": 0.5, "callback": _open_map})
	_add(&"lights", &"lights", KIND_TAP, &"headlights", TL, Vector2(196, 250), 40.0, {"icon_scale": 0.5})
	_add(&"horn", &"horn", KIND_HOLD, &"horn", TL, Vector2(296, 250), 40.0, {"icon_scale": 0.5})
	_add(&"reset", &"reset", KIND_TAP, &"reset_car", TL, Vector2(396, 250), 40.0, {"icon_scale": 0.5, "hold_time": 0.45})
	_add(&"camera", &"camera", KIND_TAP, &"camera_next", TR, Vector2(84, 70), 46.0, {"icon_scale": 0.5})
	_add(&"shift_up", &"shift_up", KIND_TAP, &"gear_up", BR, Vector2(620, 330), 62.0, {"manual_only": true, "icon_scale": 0.5})
	_add(&"shift_down", &"shift_down", KIND_TAP, &"gear_down", BR, Vector2(620, 150), 62.0, {"manual_only": true, "icon_scale": 0.5})
	for b: Btn in _btns:
		b.visible = not b.manual_only


func _open_map() -> void:
	if Game.hud != null:
		Game.hud.call(&"open_map")


# ------------------------------------------------------------------ layout / settings

func _on_setting(key: String, _value: Variant) -> void:
	match key:
		"touch_controls":
			_apply_mode()
		"touch_scale", "touch_opacity":
			_layout()


func _apply_mode() -> void:
	var on := TouchMode.enabled()
	visible = on
	set_process(on)
	if not on:
		_release_all()


func _on_visibility() -> void:
	if not is_visible_in_tree():
		_release_all()


func _layout() -> void:
	var s := clampf(float(Settings.get_value("touch_scale", 1.0)), 0.6, 1.5)
	_opacity = clampf(float(Settings.get_value("touch_opacity", 0.85)), 0.25, 1.0)
	var ins := TouchMode.safe_insets(size)
	for b: Btn in _btns:
		var o := b.offset * s
		match b.corner:
			TL:
				b.center = Vector2(ins.x + o.x, ins.y + o.y)
			TR:
				b.center = Vector2(size.x - ins.z - o.x, ins.y + o.y)
			BL:
				b.center = Vector2(ins.x + o.x, size.y - ins.w - o.y)
			_:
				b.center = Vector2(size.x - ins.z - o.x, size.y - ins.w - o.y)
		b.r = b.radius * s
	queue_redraw()


# ------------------------------------------------------------------ per-frame

func _process(delta: float) -> void:
	var now := Time.get_ticks_msec() * 0.001
	var car: CarController = Game.player_car if Game.player_car != null and is_instance_valid(Game.player_car) else null
	var manual := car != null and not car.auto_gearbox
	var lights := car != null and car.headlights_on
	var dirty := false
	if lights != _lights_on:
		_lights_on = lights
		dirty = true
	for b: Btn in _btns:
		var vis := manual or not b.manual_only
		if vis != b.visible:
			b.visible = vis
			if not vis:
				_drop(b)
			dirty = true
		if not b.visible:
			continue
		if b.pressed and b.hold_time > 0.0 and not b.fired:
			b.held_t += delta
			dirty = true
			if b.held_t >= b.hold_time:
				b.fired = true
				_send(b, true)
				_haptic(30)
		if b.sent and b.kind == KIND_TAP and now - b.sent_t >= TAP_TIME:
			_send(b, false)
		var target := 1.0 if b.pressed else 0.0
		if not is_equal_approx(b.anim, target):
			b.anim = move_toward(b.anim, target, delta * 10.0)
			dirty = true
	if dirty:
		queue_redraw()


# ------------------------------------------------------------------ input

func _can_use() -> bool:
	return visible and is_visible_in_tree() and not Game.is_overlay_open() and not Game.photo_mode


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			if _can_use() and _finger_down(st.index, make_canvas_position_local(st.position)):
				get_viewport().set_input_as_handled()
		elif _fingers.has(st.index):
			_finger_up(st.index)
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if _fingers.has(sd.index):
			_finger_move(sd.index, make_canvas_position_local(sd.position))
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		# Mouse events emulated from touches (device -1) are skipped: the touch itself was handled above.
		if mb.device == InputEvent.DEVICE_ID_EMULATION or mb.button_index != MOUSE_BUTTON_LEFT:
			return
		if mb.pressed:
			if _can_use() and _finger_down(MOUSE_ID, make_canvas_position_local(mb.position)):
				get_viewport().set_input_as_handled()
		elif _fingers.has(MOUSE_ID):
			_finger_up(MOUSE_ID)
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if mm.device != InputEvent.DEVICE_ID_EMULATION and _fingers.has(MOUSE_ID):
			_finger_move(MOUSE_ID, make_canvas_position_local(mm.position))


func _hit(pos: Vector2) -> Btn:
	var best: Btn = null
	var best_k := INF
	for b: Btn in _btns:
		if not b.visible:
			continue
		var k := pos.distance_to(b.center) / (b.r * b.grow)
		if k <= 1.0 and k < best_k:
			best_k = k
			best = b
	return best


func _finger_down(id: int, pos: Vector2) -> bool:
	var b := _hit(pos)
	if b == null:
		return false
	if b.finger >= 0:
		return true
	_fingers[id] = b
	_press(b, id)
	return true


func _press(b: Btn, id: int) -> void:
	b.finger = id
	b.pressed = true
	b.held_t = 0.0
	b.fired = false
	_haptic(12)
	match b.kind:
		KIND_HOLD:
			_send(b, true)
		KIND_TAP:
			if b.hold_time <= 0.0:
				_send(b, true)
		KIND_CALL:
			if b.callback.is_valid():
				b.callback.call()
	queue_redraw()


func _finger_up(id: int) -> void:
	var b: Btn = _fingers.get(id)
	_fingers.erase(id)
	if b != null:
		_release(b)


func _finger_move(id: int, pos: Vector2) -> void:
	var b: Btn = _fingers.get(id)
	if b == null:
		return
	if b.group != 0:
		# Slide between buttons of the same group (steer left <-> right) without lifting.
		var near: Btn = null
		var near_d := INF
		for o: Btn in _btns:
			if o.group == b.group and o.visible:
				var d := pos.distance_to(o.center)
				if d < near_d:
					near_d = d
					near = o
		if near != null and near != b and near.finger < 0 and near_d <= near.r * 1.8:
			_release(b)
			_fingers[id] = near
			_press(near, id)
		return
	if pos.distance_to(b.center) > b.r * b.slip:
		_fingers.erase(id)
		_release(b)


func _release(b: Btn) -> void:
	b.finger = -1
	b.pressed = false
	b.held_t = 0.0
	if b.kind == KIND_HOLD and b.sent:
		_send(b, false)
	queue_redraw()


func _drop(b: Btn) -> void:
	for k: int in _fingers.keys():
		if _fingers[k] == b:
			_fingers.erase(k)
	_release(b)


func _release_all() -> void:
	_fingers.clear()
	for b: Btn in _btns:
		b.finger = -1
		b.pressed = false
		b.held_t = 0.0
		b.anim = 0.0
		if b.sent:
			_send(b, false)
	queue_redraw()


func _send(b: Btn, down: bool) -> void:
	if b.action == &"" or b.sent == down:
		return
	b.sent = down
	b.sent_t = Time.get_ticks_msec() * 0.001
	var ev := InputEventAction.new()
	ev.action = b.action
	ev.pressed = down
	ev.strength = 1.0 if down else 0.0
	Input.parse_input_event(ev)


func _haptic(ms: int) -> void:
	if bool(Settings.get_value("touch_haptics", true)):
		Input.vibrate_handheld(ms)


# ------------------------------------------------------------------ drawing

func _draw() -> void:
	for b: Btn in _btns:
		if b.visible:
			_draw_button(b)


func _draw_button(b: Btn) -> void:
	var a := _opacity
	var k := b.anim
	var r := b.r * (1.0 - 0.06 * k)
	var c := b.center
	var tint := b.tint
	if b.glow:
		draw_circle(c, r * 1.22, Color(tint, (0.10 + 0.14 * k) * a), true, -1.0, true)
	draw_circle(c + Vector2(0, 5), r, Color(0, 0, 0, 0.16 * a), true, -1.0, true)
	var fill := Color(0.03, 0.04, 0.07, 0.34 * a).lerp(Color(1, 1, 1, 0.26 * a), k)
	if b.glow:
		fill = Color(tint, 0.22 * a).lerp(Color(tint, 0.55 * a), k)
	draw_circle(c, r, fill, true, -1.0, true)
	draw_arc(c, r - 1.5, 0.0, TAU, 72, Color(tint, (0.72 + 0.28 * k) * a), 2.6 + 1.2 * k, true)
	if b.hold_time > 0.0 and b.held_t > 0.0:
		var p := clampf(b.held_t / b.hold_time, 0.0, 1.0)
		draw_arc(c, r - 1.5, -PI * 0.5, -PI * 0.5 + TAU * p, 48, Style.ACCENT, 6.0, true)
	var icol := Color(0.95, 0.96, 0.98, (0.82 + 0.18 * k) * a)
	var lit := b.id == &"lights" and _lights_on
	Icons.draw(self, b.icon, c, r * b.icon_scale, icol, lit)
