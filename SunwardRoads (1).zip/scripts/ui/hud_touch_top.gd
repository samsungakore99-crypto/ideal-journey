extends Control
## Touch-layout top HUD (replaces the bottom-right instrument cluster, which the pedals now cover): a wide
## speed bar with the digital speed under it and the gear badge on its left, and the credits pill beside the
## camera button. Redraws only when what it shows changes.

const Style := preload("res://scripts/ui/ui_style.gd")
const TouchMode := preload("res://scripts/ui/touch_mode.gd")

const BAR_W := 520.0
const BAR_H := 18.0
const BAR_Y := 26.0

var _car: CarController
var _speed: float = 0.0
var _key: String = ""
var _t: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = TouchMode.enabled()
	Settings.changed.connect(_on_setting)
	resized.connect(func() -> void: _key = "")


func _on_setting(key: String, _value: Variant) -> void:
	if key == "touch_controls":
		visible = TouchMode.enabled()
	if key in ["touch_controls", "touch_scale", "units_mph"]:
		_key = ""


func _process(delta: float) -> void:
	if not visible:
		return
	_t += delta
	var car := Game.player_car if Game.player_car != null and is_instance_valid(Game.player_car) else null
	if car != _car:
		_car = car
		_key = ""
	if _car == null or _car.data == null:
		return
	_speed = lerpf(_speed, absf(_car.get_speed_kmh()), clampf(delta * 12.0, 0.0, 1.0))
	var top := maxf(_car.data.top_speed_kmh, 120.0)
	var fill := int(clampf(_speed / top, 0.0, 1.0) * 200.0)
	var flash := 1 if _car.limiter_hit and fmod(_t, 0.12) < 0.07 else 0
	var gear := _car.gear
	var key := "%d|%d|%d|%d|%d|%s" % [int(round(Style.speed_value(_speed))), fill, flash, gear, Game.credits, Style.speed_unit()]
	if key != _key:
		_key = key
		queue_redraw()


func _gear_text() -> String:
	var g := _car.gear
	return "R" if g < 0 else ("N" if g == 0 else str(g))


func _draw() -> void:
	if _car == null or _car.data == null:
		return
	var cx := size.x * 0.5
	var top := maxf(_car.data.top_speed_kmh, 120.0)
	var frac := clampf(_speed / top, 0.0, 1.0)
	# Speed bar.
	var bar := Rect2(Vector2(cx - BAR_W * 0.5, BAR_Y), Vector2(BAR_W, BAR_H))
	Style.draw_round_rect(self, bar.grow(3.0), Color(0, 0, 0, 0.35), 12)
	Style.draw_round_rect(self, bar, Color(1, 1, 1, 0.14), 9)
	if frac > 0.004:
		var col := Style.SKY
		if _car.limiter_hit and fmod(_t, 0.12) < 0.07:
			col = Style.BAD
		var fw := maxf(BAR_W * frac, BAR_H)
		Style.draw_round_rect(self, Rect2(bar.position, Vector2(fw, BAR_H)), Color(col, 0.28), 9)
		Style.draw_round_rect(self, Rect2(bar.position + Vector2(0, 2), Vector2(fw, BAR_H - 4)), col, 7)
		draw_line(bar.position + Vector2(8, 4.5), bar.position + Vector2(fw - 8, 4.5), Color(1, 1, 1, 0.45), 2.0, true)
	# Gear badge (left of the bar).
	var gr := Rect2(Vector2(bar.position.x - 74.0, BAR_Y - 11.0), Vector2(56, 40))
	Style.draw_round_rect(self, gr, Style.BG_STRONG, 10, 2, Color(Style.SKY, 0.8))
	Style.draw_text(self, _gear_text(), gr.position + Vector2(0, 31), 30, Style.TEXT, HORIZONTAL_ALIGNMENT_CENTER, gr.size.x, 700, true, 0, 0.3)
	# Digital speed.
	var v := int(round(Style.speed_value(_speed)))
	Style.draw_text(self, str(v), Vector2(cx - 200.0, 106.0), 66, Style.TEXT, HORIZONTAL_ALIGNMENT_CENTER, 400.0, 700, true, 0, 0.5)
	Style.draw_text(self, Style.speed_unit(), Vector2(cx - 200.0, 134.0), 18, Style.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER, 400.0, 600, false, 3, 0.4)
	_draw_credits()


func _draw_credits() -> void:
	var s := clampf(float(Settings.get_value("touch_scale", 1.0)), 0.6, 1.5)
	var ins := TouchMode.safe_insets(size)
	var text := str(Game.credits)
	var tw := Style.text_width(text, 28, 700)
	var w := tw + 92.0
	var h := 56.0
	var right := size.x - ins.z - (84.0 + 46.0) * s - 22.0
	var rect := Rect2(Vector2(right - w, ins.y + 70.0 * s - h * 0.5), Vector2(w, h))
	Style.draw_round_rect(self, rect, Style.BG_STRONG, 28, 1, Style.LINE)
	var cc := rect.position + Vector2(36, h * 0.5)
	var hex := PackedVector2Array()
	for i in 6:
		var a := PI / 6.0 + TAU * i / 6.0
		hex.append(cc + Vector2(cos(a), sin(a)) * 21.0)
	draw_colored_polygon(hex, Style.GOLD)
	Style.draw_text(self, "C", cc + Vector2(-20, 9), 26, Style.INK, HORIZONTAL_ALIGNMENT_CENTER, 40.0, 700, false, 0, 0.0)
	Style.draw_text(self, text, rect.position + Vector2(68, 38), 28, Style.TEXT, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 700, false, 0, 0.4)
